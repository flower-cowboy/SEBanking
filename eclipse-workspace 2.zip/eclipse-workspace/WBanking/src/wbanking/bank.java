package wbanking;

public class bank {
	public static void main(String[] args) {
	    System.out.println("Hello World");
	  }
	//Create new instance of class
	//login credentials
	//Switch statement with each function ie Withdraw....
	/*
	Call other functions based on user input
        switch (userInput) {
            case "deposit":
                bankingApp.deposit(amount);
                break;
            case "withdraw":
                bankingApp.withdraw(amount);
                break;
            case "transfer":
                bankingApp.transfer(recipient, amount);
                break;
            case "info":
                bankingApp.getInfo();
                break;
            default:
                System.out.println("Invalid input. Please try again.");
        }
	*/
}
