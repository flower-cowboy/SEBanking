/**
 * 
 */
/**
 * @author robinmartin
 *
 */
module WBanking {
}